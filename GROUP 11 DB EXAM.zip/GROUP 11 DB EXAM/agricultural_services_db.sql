-- =====================================================================
-- AGRICULTURAL SERVICES MANAGEMENT SYSTEM
-- Ministry of Agriculture - Coffee Sector
-- MySQL 8.0+
-- =====================================================================

DROP DATABASE IF EXISTS agri_services;
CREATE DATABASE agri_services CHARACTER SET utf8mb4;
USE agri_services;

-- =====================================================================
-- 1. LOCATION HIERARCHY
-- =====================================================================
CREATE TABLE region (
  region_id   INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE district (
  district_id INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80) NOT NULL,
  region_id   INT NOT NULL,
  FOREIGN KEY (region_id) REFERENCES region(region_id),
  UNIQUE (name, region_id)
);

CREATE TABLE subcounty (
  subcounty_id INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(80) NOT NULL,
  district_id  INT NOT NULL,
  FOREIGN KEY (district_id) REFERENCES district(district_id),
  UNIQUE (name, district_id)
);

-- =====================================================================
-- 2. PERSON + OVERLAPPING SPECIALIZATION (FARMER / EXTENSION_WORKER)
-- =====================================================================
CREATE TABLE person (
  person_id  INT AUTO_INCREMENT PRIMARY KEY,
  full_name  VARCHAR(120) NOT NULL,
  phone      VARCHAR(20)  UNIQUE,
  email      VARCHAR(120) UNIQUE,
  CHECK (phone IS NOT NULL OR email IS NOT NULL)
);

CREATE TABLE farmer (
  person_id        INT PRIMARY KEY,
  registration_date DATE NOT NULL DEFAULT (CURRENT_DATE),
  bank_account_no  VARCHAR(40),
  FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE CASCADE
);

CREATE TABLE extension_worker (
  person_id    INT PRIMARY KEY,
  hire_date    DATE NOT NULL,
  qualification VARCHAR(120) NOT NULL,
  region_id    INT NOT NULL,
  FOREIGN KEY (person_id) REFERENCES person(person_id) ON DELETE CASCADE,
  FOREIGN KEY (region_id) REFERENCES region(region_id)
);

-- =====================================================================
-- 3. COFFEE_TYPE (DISJOINT: ARABICA xor ROBUSTA)
-- =====================================================================
CREATE TABLE coffee_type (
  coffee_type_id INT AUTO_INCREMENT PRIMARY KEY,
  variety_name   VARCHAR(80) NOT NULL UNIQUE,
  subtype        ENUM('ARABICA','ROBUSTA') NOT NULL
);

CREATE TABLE arabica (
  coffee_type_id     INT PRIMARY KEY,
  altitude_requirement VARCHAR(40),
  flavor_profile     VARCHAR(120),
  FOREIGN KEY (coffee_type_id) REFERENCES coffee_type(coffee_type_id) ON DELETE CASCADE
);

CREATE TABLE robusta (
  coffee_type_id   INT PRIMARY KEY,
  caffeine_content DECIMAL(4,2),
  disease_resistance VARCHAR(80),
  FOREIGN KEY (coffee_type_id) REFERENCES coffee_type(coffee_type_id) ON DELETE CASCADE
);

-- Disjoint enforcement triggers
DELIMITER //
CREATE TRIGGER trg_arabica_disjoint BEFORE INSERT ON arabica
FOR EACH ROW BEGIN
  IF (SELECT subtype FROM coffee_type WHERE coffee_type_id=NEW.coffee_type_id) <> 'ARABICA' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Disjoint violation: not ARABICA';
  END IF;
  IF EXISTS (SELECT 1 FROM robusta WHERE coffee_type_id=NEW.coffee_type_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Disjoint violation: already ROBUSTA';
  END IF;
END//
CREATE TRIGGER trg_robusta_disjoint BEFORE INSERT ON robusta
FOR EACH ROW BEGIN
  IF (SELECT subtype FROM coffee_type WHERE coffee_type_id=NEW.coffee_type_id) <> 'ROBUSTA' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Disjoint violation: not ROBUSTA';
  END IF;
  IF EXISTS (SELECT 1 FROM arabica WHERE coffee_type_id=NEW.coffee_type_id) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Disjoint violation: already ARABICA';
  END IF;
END//
DELIMITER ;

-- =====================================================================
-- 4. SUPPORT_TYPE (DISJOINT: INPUT / FINANCIAL / TRAINING)
-- =====================================================================
CREATE TABLE support_type (
  support_type_id INT AUTO_INCREMENT PRIMARY KEY,
  type_name       VARCHAR(80) NOT NULL UNIQUE,
  unit_of_measure VARCHAR(30) NOT NULL,
  category        ENUM('INPUT','FINANCIAL','TRAINING') NOT NULL
);

CREATE TABLE input_support (
  support_type_id   INT PRIMARY KEY,
  input_category    VARCHAR(60),
  recommended_usage VARCHAR(200),
  supplier_name     VARCHAR(120),
  FOREIGN KEY (support_type_id) REFERENCES support_type(support_type_id) ON DELETE CASCADE
);

CREATE TABLE financial_support (
  support_type_id     INT PRIMARY KEY,
  amount_allocated    DECIMAL(14,2) NOT NULL CHECK (amount_allocated >= 0),
  funding_source      VARCHAR(120),
  disbursement_method VARCHAR(60),
  FOREIGN KEY (support_type_id) REFERENCES support_type(support_type_id) ON DELETE CASCADE
);

CREATE TABLE training_support (
  support_type_id INT PRIMARY KEY,
  training_topic  VARCHAR(120),
  duration_days   INT CHECK (duration_days > 0),
  facilitator     VARCHAR(120),
  FOREIGN KEY (support_type_id) REFERENCES support_type(support_type_id) ON DELETE CASCADE
);

DELIMITER //
CREATE TRIGGER trg_input_disjoint BEFORE INSERT ON input_support
FOR EACH ROW BEGIN
  IF (SELECT category FROM support_type WHERE support_type_id=NEW.support_type_id) <> 'INPUT' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Support disjoint: not INPUT';
  END IF;
END//
CREATE TRIGGER trg_fin_disjoint BEFORE INSERT ON financial_support
FOR EACH ROW BEGIN
  IF (SELECT category FROM support_type WHERE support_type_id=NEW.support_type_id) <> 'FINANCIAL' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Support disjoint: not FINANCIAL';
  END IF;
END//
CREATE TRIGGER trg_train_disjoint BEFORE INSERT ON training_support
FOR EACH ROW BEGIN
  IF (SELECT category FROM support_type WHERE support_type_id=NEW.support_type_id) <> 'TRAINING' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Support disjoint: not TRAINING';
  END IF;
END//
DELIMITER ;

-- =====================================================================
-- 5. FARM + RELATED
-- =====================================================================
CREATE TABLE farm (
  farm_id       INT AUTO_INCREMENT PRIMARY KEY,
  farmer_id     INT NOT NULL,
  registered_by INT NOT NULL,
  farm_size     DECIMAL(8,2) NOT NULL CHECK (farm_size > 0),
  subcounty_id  INT,
  FOREIGN KEY (farmer_id) REFERENCES farmer(person_id),
  FOREIGN KEY (registered_by) REFERENCES extension_worker(person_id),
  FOREIGN KEY (subcounty_id) REFERENCES subcounty(subcounty_id)
);

CREATE TABLE farm_coffee_type (
  farm_id        INT,
  coffee_type_id INT,
  PRIMARY KEY (farm_id, coffee_type_id),
  FOREIGN KEY (farm_id) REFERENCES farm(farm_id) ON DELETE CASCADE,
  FOREIGN KEY (coffee_type_id) REFERENCES coffee_type(coffee_type_id)
);

CREATE TABLE coffee_production (
  production_id  INT AUTO_INCREMENT PRIMARY KEY,
  farm_id        INT NOT NULL,
  coffee_type_id INT NOT NULL,
  quantity       DECIMAL(10,2) NOT NULL CHECK (quantity > 0),
  harvest_date   DATE NOT NULL,
  FOREIGN KEY (farm_id) REFERENCES farm(farm_id),
  FOREIGN KEY (coffee_type_id) REFERENCES coffee_type(coffee_type_id)
);

CREATE TABLE coffee_sale (
  sale_id       INT AUTO_INCREMENT PRIMARY KEY,
  production_id INT NOT NULL,
  quantity_sold DECIMAL(10,2) NOT NULL CHECK (quantity_sold > 0),
  price         DECIMAL(12,2) NOT NULL CHECK (price >= 0),
  buyer_name    VARCHAR(120) NOT NULL,
  FOREIGN KEY (production_id) REFERENCES coffee_production(production_id)
);

CREATE TABLE pest_disease (
  pest_id     INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE farm_visit (
  visit_id            INT AUTO_INCREMENT PRIMARY KEY,
  farm_id             INT NOT NULL,
  extension_worker_id INT NOT NULL,
  visit_date          DATE NOT NULL,
  notes               TEXT,
  pest_id             INT,
  FOREIGN KEY (farm_id) REFERENCES farm(farm_id),
  FOREIGN KEY (extension_worker_id) REFERENCES extension_worker(person_id),
  FOREIGN KEY (pest_id) REFERENCES pest_disease(pest_id)
);

CREATE TABLE support_distribution (
  distribution_id   INT AUTO_INCREMENT PRIMARY KEY,
  farm_id           INT NOT NULL,
  support_type_id   INT NOT NULL,
  quantity          DECIMAL(12,2) NOT NULL CHECK (quantity > 0),
  distribution_date DATE NOT NULL,
  FOREIGN KEY (farm_id) REFERENCES farm(farm_id),
  FOREIGN KEY (support_type_id) REFERENCES support_type(support_type_id)
);

-- =====================================================================
-- 6. TRAINING (DISJOINT)
-- =====================================================================
CREATE TABLE training_session (
  session_id   INT AUTO_INCREMENT PRIMARY KEY,
  session_date DATE NOT NULL,
  topic        VARCHAR(150) NOT NULL,
  mode         ENUM('FIELD','WORKSHOP','ONLINE') NOT NULL
);

CREATE TABLE field_training (
  session_id         INT PRIMARY KEY,
  farm_id            INT NOT NULL,
  demonstration_type VARCHAR(120),
  tools_used         VARCHAR(200),
  FOREIGN KEY (session_id) REFERENCES training_session(session_id) ON DELETE CASCADE,
  FOREIGN KEY (farm_id) REFERENCES farm(farm_id)
);

CREATE TABLE workshop_training (
  session_id INT PRIMARY KEY,
  venue      VARCHAR(150),
  capacity   INT CHECK (capacity > 0),
  organizer  VARCHAR(120),
  FOREIGN KEY (session_id) REFERENCES training_session(session_id) ON DELETE CASCADE
);

CREATE TABLE online_training (
  session_id     INT PRIMARY KEY,
  platform       VARCHAR(80),
  link           VARCHAR(255),
  duration_hours DECIMAL(4,1) CHECK (duration_hours > 0),
  FOREIGN KEY (session_id) REFERENCES training_session(session_id) ON DELETE CASCADE
);

DELIMITER //
CREATE TRIGGER trg_field_disjoint BEFORE INSERT ON field_training
FOR EACH ROW BEGIN
  IF (SELECT mode FROM training_session WHERE session_id=NEW.session_id) <> 'FIELD' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Training disjoint: not FIELD';
  END IF;
END//
CREATE TRIGGER trg_workshop_disjoint BEFORE INSERT ON workshop_training
FOR EACH ROW BEGIN
  IF (SELECT mode FROM training_session WHERE session_id=NEW.session_id) <> 'WORKSHOP' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Training disjoint: not WORKSHOP';
  END IF;
END//
CREATE TRIGGER trg_online_disjoint BEFORE INSERT ON online_training
FOR EACH ROW BEGIN
  IF (SELECT mode FROM training_session WHERE session_id=NEW.session_id) <> 'ONLINE' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Training disjoint: not ONLINE';
  END IF;
END//
DELIMITER ;

CREATE TABLE training_attendance (
  attendance_id INT AUTO_INCREMENT PRIMARY KEY,
  session_id    INT NOT NULL,
  farmer_id     INT NOT NULL,
  UNIQUE (session_id, farmer_id),
  FOREIGN KEY (session_id) REFERENCES training_session(session_id),
  FOREIGN KEY (farmer_id) REFERENCES farmer(person_id)
);

-- =====================================================================
-- 7. AUTH
-- =====================================================================
CREATE TABLE role (
  role_id   INT AUTO_INCREMENT PRIMARY KEY,
  role_name ENUM('admin','extension_worker','data_entry_clerk','viewer') NOT NULL UNIQUE
);

CREATE TABLE app_user (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role_id       INT NOT NULL,
  person_id     INT,
  FOREIGN KEY (role_id) REFERENCES role(role_id),
  FOREIGN KEY (person_id) REFERENCES person(person_id)
);

-- Minimum participation: prevent deleting a farmer's last farm
DELIMITER //
CREATE TRIGGER trg_farmer_min_farm BEFORE DELETE ON farm
FOR EACH ROW BEGIN
  IF (SELECT COUNT(*) FROM farm WHERE farmer_id=OLD.farmer_id) <= 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Farmer must own at least one farm';
  END IF;
END//
DELIMITER ;

-- =====================================================================
-- 11. ROLE-BASED ACCESS CONTROL (DATABASE-LEVEL SECURITY)
-- =====================================================================

-- 1. CREATE ROLES
CREATE ROLE IF NOT EXISTS admin_role;
CREATE ROLE IF NOT EXISTS extension_worker_role;
CREATE ROLE IF NOT EXISTS data_entry_role;
CREATE ROLE IF NOT EXISTS viewer_role;

-- =====================================================================
-- 2. ASSIGN PRIVILEGES TO ROLES
-- =====================================================================

-- ADMIN: Full access
GRANT ALL PRIVILEGES ON agri_services.* TO admin_role;

-- EXTENSION WORKER:
-- Can view data + record visits + training attendance
GRANT SELECT ON agri_services.* TO extension_worker_role;
GRANT INSERT, UPDATE ON agri_services.farm_visit TO extension_worker_role;
GRANT INSERT ON agri_services.training_attendance TO extension_worker_role;

-- DATA ENTRY CLERK:
-- Can insert core data
GRANT SELECT ON agri_services.* TO data_entry_role;
GRANT INSERT ON agri_services.person TO data_entry_role;
GRANT INSERT ON agri_services.farmer TO data_entry_role;
GRANT INSERT ON agri_services.farm TO data_entry_role;
GRANT INSERT ON agri_services.coffee_production TO data_entry_role;
GRANT INSERT ON agri_services.support_distribution TO data_entry_role;

-- VIEWER:
-- Read-only access
GRANT SELECT ON agri_services.* TO viewer_role;

-- =====================================================================
-- 3. CREATE DATABASE USERS
-- =====================================================================

CREATE USER IF NOT EXISTS 'admin1'@'localhost' IDENTIFIED BY 'Admin@123';
CREATE USER IF NOT EXISTS 'jesse'@'localhost' IDENTIFIED BY 'User@123';
CREATE USER IF NOT EXISTS 'clerk1'@'localhost' IDENTIFIED BY 'Clerk@123';
CREATE USER IF NOT EXISTS 'viewer1'@'localhost' IDENTIFIED BY 'Viewer@123';

-- =====================================================================
-- 4. ASSIGN ROLES TO USERS
-- =====================================================================

GRANT admin_role TO 'admin1'@'localhost';
GRANT extension_worker_role TO 'jesse'@'localhost';
GRANT data_entry_role TO 'clerk1'@'localhost';
GRANT viewer_role TO 'viewer1'@'localhost';

-- =====================================================================
-- 5. ACTIVATE DEFAULT ROLES
-- =====================================================================

SET DEFAULT ROLE ALL TO
'admin1'@'localhost',
'jesse'@'localhost',
'clerk1'@'localhost',
'viewer1'@'localhost';



-- Grant access to views only
GRANT SELECT ON agri_services.farmer_summary TO viewer_role;
GRANT SELECT ON agri_services.production_summary TO viewer_role;
GRANT SELECT ON agri_services.support_distribution_report TO viewer_role;

-- =====================================================================
-- END OF SECURITY CONFIGURATION
-- =====================================================================

-- =====================================================================
-- 8. STORED PROCEDURES
-- =====================================================================
DELIMITER //
CREATE PROCEDURE register_farmer(
  IN p_name VARCHAR(120), IN p_phone VARCHAR(20),
  IN p_email VARCHAR(120), IN p_bank VARCHAR(40),
  OUT p_id INT)
BEGIN
  INSERT INTO person(full_name,phone,email) VALUES(p_name,p_phone,p_email);
  SET p_id = LAST_INSERT_ID();
  INSERT INTO farmer(person_id,registration_date,bank_account_no)
    VALUES(p_id, CURRENT_DATE, p_bank);
END//

CREATE PROCEDURE add_farm(
  IN p_farmer INT, IN p_worker INT,
  IN p_size DECIMAL(8,2), IN p_sub INT, OUT p_farm INT)
BEGIN
  INSERT INTO farm(farmer_id,registered_by,farm_size,subcounty_id)
    VALUES(p_farmer,p_worker,p_size,p_sub);
  SET p_farm = LAST_INSERT_ID();
END//

CREATE PROCEDURE record_production(
  IN p_farm INT, IN p_type INT,
  IN p_qty DECIMAL(10,2), IN p_date DATE)
BEGIN
  INSERT INTO coffee_production(farm_id,coffee_type_id,quantity,harvest_date)
    VALUES(p_farm,p_type,p_qty,p_date);
END//

CREATE PROCEDURE distribute_support(
  IN p_farm INT, IN p_type INT,
  IN p_qty DECIMAL(12,2), IN p_date DATE)
BEGIN
  INSERT INTO support_distribution(farm_id,support_type_id,quantity,distribution_date)
    VALUES(p_farm,p_type,p_qty,p_date);
END//

CREATE PROCEDURE record_farm_visit(
  IN p_farm INT, IN p_worker INT,
  IN p_date DATE, IN p_notes TEXT, IN p_pest INT)
BEGIN
  INSERT INTO farm_visit(farm_id,extension_worker_id,visit_date,notes,pest_id)
    VALUES(p_farm,p_worker,p_date,p_notes,p_pest);
END//
DELIMITER ;

-- =====================================================================
-- 9. VIEWS
-- =====================================================================
CREATE VIEW farmer_summary AS
SELECT p.person_id, p.full_name, p.phone, f.registration_date,
       COUNT(fm.farm_id) AS total_farms,
       COALESCE(SUM(fm.farm_size),0) AS total_acreage
FROM farmer f JOIN person p ON p.person_id=f.person_id
LEFT JOIN farm fm ON fm.farmer_id=f.person_id
GROUP BY p.person_id, p.full_name, p.phone, f.registration_date;

CREATE VIEW production_summary AS
SELECT cp.production_id, p.full_name AS farmer, ct.variety_name,
       cp.quantity, cp.harvest_date
FROM coffee_production cp
JOIN farm fm ON fm.farm_id=cp.farm_id
JOIN person p ON p.person_id=fm.farmer_id
JOIN coffee_type ct ON ct.coffee_type_id=cp.coffee_type_id;

CREATE VIEW support_distribution_report AS
SELECT sd.distribution_id, p.full_name AS farmer, st.type_name,
       st.category, sd.quantity, sd.distribution_date
FROM support_distribution sd
JOIN farm fm ON fm.farm_id=sd.farm_id
JOIN person p ON p.person_id=fm.farmer_id
JOIN support_type st ON st.support_type_id=sd.support_type_id;


